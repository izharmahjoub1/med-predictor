<?php

use Illuminate\Support\Facades\Route;

Route::get('/test-simple', function () {
    return 'Test simple fonctionne';
}); 