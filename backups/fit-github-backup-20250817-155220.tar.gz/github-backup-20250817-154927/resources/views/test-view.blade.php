<!DOCTYPE html>
<html>
<head>
    <title>Test View</title>
</head>
<body>
    <h1>Test View Working</h1>
    <p>This is a simple test view to debug the 500 error.</p>
</body>
</html> 