<?php

namespace App\Services;

class FifaCacheService
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
