<?php
// Générateur de Dataset - 50 Joueurs Ligue Professionnelle 1 Tunisie 2024-2025
// FIT Score - 5 Piliers : Health, Performance, SDOH, Market Value, Adherence

$clubs = [
    "Espérance de Tunis",
    "Club Africain",
    "Étoile du Sahel",
    "CS Sfaxien",
    "US Monastir",
    "CA Bizertin",
    "Stade Tunisien",
    "AS Gabès",
    "JS Kairouan",
    "Olympique Béja"
];

$postes = [
    "Gardien",
    "Défenseur central",
    "Latéral droit",
    "Latéral gauche",
    "Milieu défensif",
    "Milieu central",
    "Milieu offensif",
    "Ailier droit",
    "Ailier gauche",
    "Attaquant"
];
